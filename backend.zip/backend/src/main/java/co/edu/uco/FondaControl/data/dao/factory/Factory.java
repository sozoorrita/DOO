package co.edu.uco.FondaControl.data.dao.factory;

public enum Factory {
    POSTGRESQL
}
