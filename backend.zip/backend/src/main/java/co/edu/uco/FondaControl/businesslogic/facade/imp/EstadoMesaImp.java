package co.edu.uco.FondaControl.businesslogic.facade.imp;

import co.edu.uco.FondaControl.businesslogic.businesslogic.EstadoMesaBusinessLogic;
import co.edu.uco.FondaControl.businesslogic.businesslogic.impl.EstadoMesaImpl;
import co.edu.uco.FondaControl.crosscutting.excepciones.FondaControlException;
import co.edu.uco.FondaControl.dto.EstadoMesaDTO;
import co.edu.uco.FondaControl.businesslogic.facade.EstadoMesaFacade;
import co.edu.uco.FondaControl.data.dao.factory.DAOFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public final class EstadoMesaImp implements EstadoMesaFacade {
    private final EstadoMesaBusinessLogic businessLogic;

    @Autowired
    public EstadoMesaImp(DAOFactory daoFactory) {
        this.businessLogic = new EstadoMesaBusinessLogicImpl(daoFactory);
    }

    @Override
    public void registrarEstadoMesa(EstadoMesaDTO dto) throws FondaControlException {
        businessLogic.registrarEstadoMesa(dto);
    }

    @Override
    public void actualizarEstadoMesa(EstadoMesaDTO dto) throws FondaControlException {
        businessLogic.actualizarEstadoMesa(dto);
    }

    @Override
    public void eliminarEstadoMesa(EstadoMesaDTO dto) throws FondaControlException {
        businessLogic.eliminarEstadoMesa(dto);
    }

    @Override
    public List<EstadoMesaDTO> listarEstadoMesa() throws FondaControlException {
        return businessLogic.listarEstadoMesa();
    }
}