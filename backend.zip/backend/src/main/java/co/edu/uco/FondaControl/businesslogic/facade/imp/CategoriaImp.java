package co.edu.uco.FondaControl.businesslogic.facade.imp;

import co.edu.uco.FondaControl.businesslogic.businesslogic.CategoriaBusinessLogic;
import co.edu.uco.FondaControl.businesslogic.businesslogic.impl.CategoriaImpl;
import co.edu.uco.FondaControl.crosscutting.excepciones.FondaControlException;
import co.edu.uco.FondaControl.dto.CategoriaDTO;
import co.edu.uco.FondaControl.businesslogic.facade.CategoriaFacade;
import co.edu.uco.FondaControl.data.dao.factory.DAOFactory;
import co.edu.uco.FondaControl.data.dao.factory.Factory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public final class CategoriaImp implements CategoriaFacade {
    private final CategoriaBusinessLogic businessLogic;

    @Autowired
    public CategoriaImp(DAOFactory daoFactory) {
        this.businessLogic = new CategoriaImpl(daoFactory);
    }

    @Override
    public void registrarCategoria(CategoriaDTO dto) throws FondaControlException {
        businessLogic.registrarCategoria(dto);
    }

    @Override
    public void actualizarCategoria(CategoriaDTO dto) throws FondaControlException {
        businessLogic.actualizarCategoria(dto);
    }

    @Override
    public void eliminarCategoria(CategoriaDTO dto) throws FondaControlException {
        businessLogic.eliminarCategoria(dto);
    }

    @Override
    public List<CategoriaDTO> listarCategorias() throws FondaControlException {
        return businessLogic.listarCategorias();
    }
}
