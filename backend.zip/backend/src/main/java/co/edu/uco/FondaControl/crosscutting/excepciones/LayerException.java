package co.edu.uco.FondaControl.crosscutting.excepciones;

public enum LayerException {
	
	DATA, BUSINESS_LOGIC, API, CROSSCUTTING, GENERAL;

}
