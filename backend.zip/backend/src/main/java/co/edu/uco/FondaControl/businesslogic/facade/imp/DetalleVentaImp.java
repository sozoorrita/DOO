package co.edu.uco.FondaControl.businesslogic.facade.imp;

import co.edu.uco.FondaControl.businesslogic.businesslogic.DetalleVentaBusinessLogic;
import co.edu.uco.FondaControl.businesslogic.businesslogic.impl.DetalleVentaImpl;
import co.edu.uco.FondaControl.crosscutting.excepciones.FondaControlException;
import co.edu.uco.FondaControl.dto.DetalleVentaDTO;
import co.edu.uco.FondaControl.businesslogic.facade.DetalleVentaFacade;
import co.edu.uco.FondaControl.data.dao.factory.DAOFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public final class DetalleVentaImp implements DetalleVentaFacade {
    private final DetalleVentaBusinessLogic businessLogic;

    @Autowired
    public DetalleVentaImp(DAOFactory daoFactory) {
        this.businessLogic = new DetalleVentaImpl(daoFactory);
    }

    @Override
    public void registrarDetalleVenta(DetalleVentaDTO dto) throws FondaControlException {
        businessLogic.registrarDetalleVenta(dto);
    }

    @Override
    public void actualizarDetalleVenta(DetalleVentaDTO dto) throws FondaControlException {
        businessLogic.actualizarDetalleVenta(dto);
    }

    @Override
    public void eliminarDetalleVenta(DetalleVentaDTO dto) throws FondaControlException {
        businessLogic.eliminarDetalleVenta(dto);
    }

    @Override
    public List<DetalleVentaDTO> listarDetalleVenta() throws FondaControlException {
        return businessLogic.listarDetalleVenta();
    }
}
