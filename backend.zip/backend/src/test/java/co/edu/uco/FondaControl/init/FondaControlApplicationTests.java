package co.edu.uco.FondaControl.init;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FondaControlApplicationTests {

	@Test
	void contextLoads() {
	}

}
